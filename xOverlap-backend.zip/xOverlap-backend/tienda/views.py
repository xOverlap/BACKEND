from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import requests
from django.contrib.auth.forms import UserCreationForm

def index(request):
    return render(request, 'index.html',{
        'form': UserCreationForm()
    })

def home(request):
    urlApi = 'https://localhost:8000/clientes'
    try:
        response = requests.get(urlApi)
        if response.status_code == 200:
            data = response.json()
            tabla_html = '<table>'
            tabla_html += '<tr> <th>rut</th> <th>nombre</th> <th>apellido</th> </tr>'
            for cliente in data['lista']:
                tabla_html += '<tr>'
                tabla_html += '<td>' + cliente['rut'] + '</td>'
                tabla_html += '<td>' + cliente['nombre'] + '</td>'
                tabla_html += '<td>' + cliente['apellido'] + '</td>'
                tabla_html += '</tr>'
                return render(request, 'home.html', {
                    "tabla_html": tabla_html
                })
    except Exception as e:
        return HttpResponse(str(e), status=500)